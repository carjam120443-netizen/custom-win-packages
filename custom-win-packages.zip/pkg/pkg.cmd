@echo off
winget.exe %*
